# Schematica rendering proof

Two definitions, 18 generated configurations, awaiting visual review. The remaining
four appearances, full library and browser viewer are deferred until the user
approves this checkpoint. See [CHECKPOINT.md](CHECKPOINT.md).

Open [the proof sheet](review/proof.png), its [editable SVG](review/proof.svg),
or the [Inkscape Symbols file](review/symbols.svg). The sheet uses a 1 mm inspection
grid and blue connection markers; individual exports contain neither.

## Sources and outputs

```text
implementation/
├── definitions/              # YAML semantics: resistor-eu and opamp-supply, revision 1
├── presets.yaml             # Independent size and stroke selections
├── tex/                     # Authoritative parameterized geometry and helpers
├── core.py                  # Find, inspect, render and package converter output
├── proof.py                 # Generate only the two-symbol checkpoint
├── verify_render.py         # Palette fidelity and Inkscape serialization
├── verify_inkscape.py       # Saved GUI evidence, placement scale and clearances
├── tests/                   # Focused validation and rendering checks
├── references/
│   └── accepted-palette/    # Unmodified accepted TeX, SVG, PDF and PNG
├── review/
│   ├── configurations/     # 18 normal individual SVG exports
│   ├── tex/                # Editable TeX bundles and native CircuitikZ example
│   ├── proof.svg           # Inspection sheet, with matching PNG
│   ├── symbols.svg         # Two Medium/Medium Symbols-panel entries
│   ├── repeated.svg        # Repeated configurations with unique identifiers
│   ├── editable-label*     # Original label, edited/reopened proof, source string
│   ├── symbols-*           # Placed, unlinked and reopened GUI evidence
│   └── *.json              # Measured results
└── build/                  # Ignored intermediate files and compile logs
```

The old library remains in its existing locations. This subtree does not replace
its preferences, examples or links. The full pre-implementation backup, including
Git history and local work, is outside the repository under the workspace's
`Local/backups/pre-symbol-library-20261113/`; its manifest records every file hash.

## Local setup and build

Verified on Windows with Python 3.13.5, PyYAML 6.0.3, PyMuPDF 1.27.1,
Tectonic 0.17.0+20260731, dvisvgm 3.6 and Inkscape 1.3.2
(091e20e, 2023-11-25, custom). The Tectonic bundle used PGF/TikZ 3.1.9a and
CircuitikZ 1.4.6. PyMuPDF is needed only for verification. The text fixture uses
installed Windows Arial; the font is not distributed.

Use a Python environment and install the pinned dependencies:

```powershell
python -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements-dev.txt
```

The existing workspace environment is at `Local/venvs/symbols/`. Tectonic is
provided by the installed desktop runtime. A standalone dvisvgm was extracted
from the TeX Live Windows archive into `Local/tools/dvisvgm/`. Inkscape was already
installed. No application connections or symbol-library installation were made.

The core searches PATH and these existing local locations. On another machine,
install the tools and either put them on PATH or set `SCHEMATICA_TECTONIC`,
`SCHEMATICA_DVISVGM` and `SCHEMATICA_INKSCAPE` to their executable paths. On Windows,
prefer `inkscape.com` for command-line checks. Tectonic may download its TeX bundle
on first use; offline rebuilding on a clean machine has not been verified.

From this folder, using that Python environment:

```powershell
python proof.py
python verify_render.py
python -m unittest discover -s tests -v
```

`proof.py` regenerates the 18 configurations, inspection sheet, repeated-copy file,
Symbols library, text fixture and native CircuitikZ example. It leaves the separately
saved GUI evidence untouched. After performing the GUI steps below, validate those
files with `python verify_inkscape.py`. That check depends on PDFs produced by
`verify_render.py`. There is no viewer to launch at this checkpoint.

## Core interface and integration handoff

```powershell
python core.py find "op-amp"
python core.py inspect opamp-supply --size small --stroke thick
python core.py render resistor-eu --size medium --stroke medium --output build/custom-export
```

Python callers can use `find_symbols(query)`, `get_definition(id)`,
`resolve_settings(definition, size, stroke)`, `inspect_symbol(id, size, stroke)` and
`render_symbol(id, size, stroke, output=None)`. Results are JSON-compatible records.
Inspection recompiles to avoid stale geometry. Rendering writes `symbol.tex`, all
required `.sty`/`.tex` helpers, XDV, raw and packaged SVG, `symbol.scmeta`,
`resolved.json` and logs into the output directory.

Stable symbol IDs are `resistor-eu` and `opamp-supply`, both revision 1. YAML carries
descriptions, types, attributes, semantic pins and graphical part IDs. TeX owns the
construction formulas and emits the resolved dimensions, pins and parts used by
inspection and validation. Initial settings are Medium/Medium. Supported sizes are
Small/Medium/Large (75/100/125%); strokes are Thin/Medium/Thick (0.15/0.20/0.30 mm).
Connections use the accepted 1 mm grid calculations and can move when size changes.

The pipeline is YAML + parameterized TeX → Tectonic XDV → dvisvgm SVG → packaging.
XDV is the XeTeX extension of DVI. The packager retains converter paths, hoists
anonymous wrappers, preserves whole-symbol → named-part groups, namespaces IDs and
references, and sets physical millimetre dimensions. It does not redraw symbols.
Normal exports are black, transparent vector artwork. Future integrations should
call this core and consume its records rather than define another symbol format.

SVG groups retain `data-symbol`, `data-revision`, `data-part` and readable Inkscape
labels. When composing copies, call `namespace_ids` with a distinct instance prefix;
copying raw XML without this step is not safe. Inkscape may replace XML IDs when
unlinking a clone, but semantic `data-part` values and labels survived the test.

## Use and edit in Inkscape

1. Open `review/symbols.svg`; open **Object → Symbols** (Ctrl+Shift+Y).
2. Choose **Current document** and click the op-amp thumbnail to copy it.
3. Create a new document, click the canvas and paste. Medium/Medium placed at
   18.200 × 13.533 mm including stroke. Save as `review/symbols-placed.svg`.
4. Select it, choose **Edit → Clone → Unlink Clone** (Shift+Alt+D), then open
   **Layers and Objects** (Ctrl+Shift+L). Expand the extra placement group and the
   named symbol group to select `body`, signs or leads. Ungrouping is not needed
   to select these named parts in the object list.
5. Save separately as `review/symbols-unlinked.svg`, close and reopen. The provided
   `symbols-reopened.svg` is an additional Inkscape serialization of this saved file.

This sequence was exercised with the supply-pin op-amp in a fresh document. Both
symbols appeared in the panel; GUI placement of the resistor was not separately
tested. The file is opened directly, so no user-profile Symbols installation is
required. Inkscape's small thumbnail setting wraps the long names; a full browsing
interface remains deferred.

For text, open `review/editable-label.svg`, use the Text tool to change **Label A**
to **Label B**, save as `editable-label-edited.svg`, close and reopen. This was done
in the GUI; `editable-label-reopened.svg` and its PNG retain editable SVG text.
`editable-label.strings.json` keeps the original source string separately.

## Use the TeX helpers

`review/tex/` contains `schematica.sty`, both recipes, and `native-circuitikz.tex`
with its compiled PDF. Compile there with:

```powershell
tectonic -X compile --untrusted native-circuitikz.tex
```

In a TikZ or CircuitikZ picture, load `schematica` and call
`\SCResistorEU{R1}{1}{0.20}` or `\SCOpampSupply{U1}{1}{0.20}`. Arguments are a unique
instance name, size factor and stroke width in millimetres. Coordinates include
`R1-a`, `R1-b`, `U1-in-plus`, `U1-in-minus`, `U1-out`, `U1-supply-plus` and
`U1-supply-minus`. The supplied example connects these anchors to native CircuitikZ
content. It proves coexistence, not a complete schematic model or editing round trip.

The standalone `symbol.tex` bundles under `review/tex/resistor-eu/` and
`review/tex/opamp-supply/` use the SVG driver. Compile with Tectonic's `--outfmt xdv`
and convert using `dvisvgm --no-fonts --exact-bbox --bbox=1mm symbol.xdv`.
Use the core for final named-part packaging. For native PDF documents, leave
the SVG driver and `\SCsvgtrueexport` out, as in the native example.

## Limits at this checkpoint

- Editable text is demonstrated for one simple Arial label. dvisvgm's subset-font
  output was normalized to installed Arial, preserving position and font size and
  restoring the literal source string. This is a fixture-specific step, not general
  editable mathematical typography or portable font embedding.
- Standalone tools emitted fontconfig/TeX-map discovery warnings. The tested
  path-only symbols and staged Arial fixture rendered correctly. Arbitrary fonts,
  other TeX bundles and other operating systems remain untested.
- Reference validation handles local `href` and attribute `url(#...)` references.
  Embedded stylesheet rules are rejected rather than silently rewritten.
- GUI edits are evidence files; they do not update YAML or TeX. Reverse import,
  personal variants and arbitrary CircuitikZ import are outside this work.
- Technical checks do not constitute user visual acceptance. Expansion, viewer
  work, commit, push, publication and application connections remain stopped.
