# Symbol implementation checkpoint

This folder implements the locally authorized first batch described in
`CHECKPOINT.md`. The accepted palette in `references/accepted-palette/` overrides
older blanket wire-relative normalization for this implementation. Size and stroke
are independent. Existing preferences, examples, and their links remain intact.

Stop after the EU resistor and supply-pin op-amp rendering proof. Expansion to the
other four appearances and the browser viewer requires the user's checkpoint
approval. No commits, pushes, publication, connections, or personal variants.

Geometry lives in parameterized TeX recipes. YAML describes semantics and supported
presets. The Python core compiles and packages converter output; it must not become
a second symbol-drawing backend. Read `README.md` and `CHECKPOINT.md` on resume.
